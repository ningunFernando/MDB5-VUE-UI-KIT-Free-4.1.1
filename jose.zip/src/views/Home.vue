<template>
  <div>
    
  </div>
  <Slider/>
</template>

<script setup lang="ts">
  import Slider from '../components/Slider.vue';
</script>

<style scoped>

</style>